﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1._5
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }

        // Ej. 1

        public static int SumarPares(int numero)
        {
            int suma = 0;
            for (int i = 2; i <= numero; i += 2)
            {
                suma += i;
            }
            return suma;
        }

        public static void Main()
        {
            Console.WriteLine(SumarPares(10));  // Ejemplo de uso
        }

        // Ej. 2

        public static bool EsPrimo(int numero)
        {
            if (numero <= 1) return false;
            for (int i = 2; i <= Math.Sqrt(numero); i++)
            {
                if (numero % i == 0)
                    return false;
            }
            return true;
        }

        // Ej. 3

        public static void ImprimirNumeros()
        {
            int i = 1;
            while (i <= 100)
            {
                Console.WriteLine(i);
                i++;
            }
        }

        // Ej. 4

        public static int Factorial(int numero)
        {
            if (numero <= 0) return 1;
            int resultado = 1;
            for (int i = 1; i <= numero; i++)
            {
                resultado *= i;
            }
            return resultado;
        }

        // Ej. 5

        public static int SumarDigitos(int numero)
        {
            int suma = 0;
            while (numero > 0)
            {
                suma += numero % 10;
                numero /= 10;
            }
            return suma;
        }

        // Ej. 6

        public static int ContarVocales(string texto)
        {
            int contador = 0;
            string vocales = "aeiouAEIOU";
            for (int i = 0; i < texto.Length; i++)
            {
                if (vocales.Contains(texto[i]))
                {
                    contador++;
                }
            }
            return contador;
        }

        // Ej. 7

        public static void ImprimirImpares(int n)
        {
            int contador = 1;
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(contador);
                contador += 2; // Saltar al siguiente impar
            }
        }

        // Ej. 8

        public static void ContarPositivosNegativosCeros(int inicio, int fin)
        {
            int positivos = 0, negativos = 0, ceros = 0;

            for (int i = inicio; i <= fin; i++)
            {
                if (i > 0)
                    positivos++;
                else if (i < 0)
                    negativos++;
                else
                    ceros++;
            }

            Console.WriteLine($"Positivos: {positivos}, Negativos: {negativos}, Ceros: {ceros}");
        }

        // Ej. 9

        public static int Potencia(int baseNum, int exponente)
        {
            int resultado = 1;
            while (exponente > 0)
            {
                resultado *= baseNum;
                exponente--;
            }
            return resultado;
        }

        // Ej. 10

        public static int Sumatoria(int numero)
        {
            int suma = 0;
            int i = 1;
            while (i <= numero)
            {
                suma += i;
                i++;
            }
            return suma;
        }

        // Ej. 11

        public static void SerieFibonacci(int n)
        {
            int a = 0, b = 1;
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(a);
                int temp = a;
                a = b;
                b = temp + b;
            }
        }

        // Ej. 12

        public static void DibujarTriangulo(int altura)
        {
            for (int i = 1; i <= altura; i++)
            {
                for (int j = 0; j < i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }

        // Ej. 13

        public static int SumarElementos(int[] arreglo)
        {
            int suma = 0;
            foreach (var num in arreglo)
            {
                suma += num;
            }
            return suma;
        }

        // Ej. 14

        public static (int max, int min) EncontrarMaximoMinimo(int[] arreglo)
        {
            if (arreglo.Length == 0) throw new ArgumentException("El arreglo no puede estar vacío.");

            int max = arreglo[0];
            int min = arreglo[0];

            foreach (var num in arreglo)
            {
                if (num > max) max = num;
                if (num < min) min = num;
            }
            return (max, min);
        }

        // Ej. 15

        public static double CalcularPromedio(int[] arreglo)
        {
            if (arreglo.Length == 0) throw new ArgumentException("El arreglo no puede estar vacío.");
            return (double)SumarElementos(arreglo) / arreglo.Length;
        }

        // Ej. 16

        public static int BuscarElemento(int[] arreglo, int elemento)
        {
            for (int i = 0; i < arreglo.Length; i++)
            {
                if (arreglo[i] == elemento)
                    return i;  
            }
            return -1;  
        }

        // Ej. 17

        public static int[] InsertarElemento(int[] arreglo, int elemento, int posicion)
        {
            if (posicion < 0 || posicion > arreglo.Length) throw new ArgumentOutOfRangeException("Posición fuera de rango.");

            int[] nuevoArreglo = new int[arreglo.Length + 1];
            for (int i = 0; i < posicion; i++)
            {
                nuevoArreglo[i] = arreglo[i];
            }
            nuevoArreglo[posicion] = elemento;
            for (int i = posicion; i < arreglo.Length; i++)
            {
                nuevoArreglo[i + 1] = arreglo[i];
            }
            return nuevoArreglo;
        }

        // Ej. 18

        public static (int[] pares, int[] impares) SepararParesImpares(int[] arreglo)
        {
            List<int> pares = new List<int>();
            List<int> impares = new List<int>();

            foreach (var num in arreglo)
            {
                if (num % 2 == 0)
                    pares.Add(num);
                else
                    impares.Add(num);
            }

            return (pares.ToArray(), impares.ToArray());
        }

        // EJ. 19

        public static int ContarRepeticiones(int[] arreglo, int numero)
        {
            int contador = 0;
            foreach (var num in arreglo)
            {
                if (num == numero) contador++;
            }
            return contador;
        }

        // ej. 20

        public static int SumarPares(int[] arreglo)
        {
            int suma = 0;
            foreach (var num in arreglo)
            {
                if (num % 2 == 0)
                    suma += num;
            }
            return suma;
        }








    }
}
